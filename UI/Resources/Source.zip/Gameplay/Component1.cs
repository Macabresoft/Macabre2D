﻿namespace TotallyUniqueName123ABC.Gameplay {

    using Macabre2D.Framework;
    using Microsoft.Xna.Framework;

    public class Component1 : BaseComponent, IUpdateableComponent {

        // Update logic goes here
        public void Update(GameTime gameTime) {
        }

        // Initialization logic goes here
        protected override void Initialize() {
        }
    }
}